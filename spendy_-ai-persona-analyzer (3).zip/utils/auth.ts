import type { User } from '../types';

// =================================================================
// ✨ SETUP: 여기에 자신의 SheetDB API URL을 붙여넣으세요!
// 1. Google Sheet 생성 -> A1 셀에 'nickname', B1 셀에 'id' 입력
// 2. sheetdb.io에서 API 생성 후 아래 URL을 교체하세요.
// =================================================================
const SHEETDB_URL = 'https://sheetdb.io/api/v1/87rucmaequvul'; 

const CURRENT_USER_KEY = 'spendy_current_user';

export const signUp = async (nickname: string, id: string): Promise<{ success: boolean, message: string }> => {
    if (!nickname || !id) {
        return { success: false, message: '닉네임과 비밀번호를 모두 입력해주세요.' };
    }

    // Server-side validation for password policy
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*[0-9]).{5,15}$/;
    if (!passwordRegex.test(id)) {
        return { success: false, message: '비밀번호는 5~15자리의 영문과 숫자 조합이어야 합니다.' };
    }

    // FIX: Removed an obsolete check against a placeholder URL ('YOUR_SHEETDB_API_URL_HERE').
    // This check caused a TypeScript error after the URL was configured, as it resulted in
    // a comparison between two distinct string literals which is always false.
    try {
        // 1. Check if nickname already exists
        const searchResponse = await fetch(`${SHEETDB_URL}/search?nickname=${nickname}`);
        if (!searchResponse.ok) {
            throw new Error('사용자 확인 중 서버에 문제가 발생했습니다.');
        }
        const existingUsers: User[] = await searchResponse.json();
        if (existingUsers.length > 0) {
            return { success: false, message: '이미 사용 중인 닉네임입니다.' };
        }

        // 2. Create new user
        const createResponse = await fetch(SHEETDB_URL, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                data: [{ nickname, id }]
            })
        });

        if (!createResponse.ok) {
             throw new Error('회원가입 중 서버에 문제가 발생했습니다.');
        }

        return { success: true, message: '회원가입이 완료되었습니다! 로그인해주세요.' };

    } catch (error) {
        console.error("SignUp Error:", error);
        return { success: false, message: (error as Error).message || '네트워크 오류가 발생했습니다.' };
    }
};

export const login = async (nickname: string, id: string): Promise<{ success: boolean, user: User | null, message: string }> => {
    if (!nickname || !id) {
        return { success: false, user: null, message: '닉네임과 비밀번호를 모두 입력해주세요.' };
    }

    // FIX: Removed an obsolete check against a placeholder URL ('YOUR_SHEETDB_API_URL_HERE').
    // This check caused a TypeScript error after the URL was configured, as it resulted in
    // a comparison between two distinct string literals which is always false.
    try {
        const response = await fetch(`${SHEETDB_URL}/search?nickname=${nickname}`);
        if (!response.ok) {
            throw new Error('로그인 중 서버에 문제가 발생했습니다.');
        }
        const users: User[] = await response.json();
        
        if (users.length === 0) {
            return { success: false, user: null, message: '존재하지 않는 닉네임입니다.' };
        }

        const user = users[0];
        if (user.id !== id) {
            return { success: false, user: null, message: '비밀번호가 일치하지 않습니다.' };
        }
        
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
        return { success: true, user, message: '로그인 성공!' };

    } catch (error) {
        console.error("Login Error:", error);
        return { success: false, user: null, message: (error as Error).message || '네트워크 오류가 발생했습니다.' };
    }
};

export const logout = (): void => {
    try {
        localStorage.removeItem(CURRENT_USER_KEY);
    } catch (e) {
        console.error("로그아웃 오류:", e);
    }
};

export const getCurrentUser = (): User | null => {
    try {
        const userJson = localStorage.getItem(CURRENT_USER_KEY);
        if (userJson) {
            return JSON.parse(userJson) as User;
        }
        return null;
    } catch (error) {
        console.error("현재 사용자 정보 가져오기 오류:", error);
        return null;
    }
};