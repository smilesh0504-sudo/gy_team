import React, { useState, useEffect, useCallback } from 'react';
import { Image as ImageIcon, X } from 'lucide-react';

const PRIMARY_BLUE = '#3182F6';

interface ImageInputProps {
    onImagesChange: (files: File[]) => void;
}

const ImageInput: React.FC<ImageInputProps> = ({ onImagesChange }) => {
    const [uploadedImages, setUploadedImages] = useState<{ file: File, url: string }[]>([]);

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const files: File[] = Array.from(e.target.files);
            if (files.length === 0) return;
            
            const newImagePreviews = files.map(file => ({ file, url: URL.createObjectURL(file) }));
            setUploadedImages(prev => [...prev, ...newImagePreviews]);
            
            // Clear the input value to allow re-uploading the same file
            e.target.value = '';
        }
    };
    
    const removeImage = useCallback((urlToRemove: string) => {
        const imageToRemove = uploadedImages.find(img => img.url === urlToRemove);
        if (imageToRemove) {
            URL.revokeObjectURL(imageToRemove.url);
        }
        setUploadedImages(prev => prev.filter(img => img.url !== urlToRemove));
    }, [uploadedImages]);

    useEffect(() => {
        onImagesChange(uploadedImages.map(img => img.file));
        
        // Cleanup object URLs when component unmounts
        return () => {
            uploadedImages.forEach(img => URL.revokeObjectURL(img.url));
        };
    // onImagesChange should not be in dependency array to avoid re-renders
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [uploadedImages]);

    return (
        <label className="cursor-pointer block">
            <div className="bg-white rounded-2xl p-6 text-center hover:bg-gray-50 transition-all border-2 border-gray-200 hover:border-blue-300 flex flex-col items-center">
                 <ImageIcon className="mb-3" style={{ color: PRIMARY_BLUE }} size={40} />
                 <span className="text-base font-bold text-gray-900 block mb-1">
                    {uploadedImages.length > 0 ? `${uploadedImages.length}개의 이미지 선택됨` : '이미지 업로드'}
                </span>
                 <span className="text-sm text-gray-500">거래내역, 영수증 이미지</span>
                 
                 {uploadedImages.length > 0 && (
                    <div className="mt-4 w-full bg-gray-50 p-3 rounded-lg">
                        <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
                            {uploadedImages.map((img) => (
                                <div key={img.url} className="relative aspect-square">
                                    <img src={img.url} alt="업로드된 이미지" className="w-full h-full object-cover rounded-lg shadow-sm" />
                                    <button 
                                        onClick={(e) => { e.preventDefault(); removeImage(img.url); }} 
                                        className="absolute -top-1.5 -right-1.5 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 shadow-md transition-transform hover:scale-110"
                                        aria-label="Remove image"
                                    >
                                        <X size={14} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                 )}
            </div>
            <input type="file" accept="image/*" multiple onChange={handleImageChange} className="hidden" />
        </label>
    );
};

export default ImageInput;
