
import React, { useState } from 'react';
import { ArrowRight, TrendingUp, AlertCircle, LoaderCircle } from 'lucide-react';
import FileInput from './FileInput';
import ImageInput from './ImageInput';
import TextInput from './TextInput';

interface UploadPageProps {
    dataCount: number;
    onFileUpload: (file: File) => void;
    onImageUpload: (files: File[]) => Promise<{ valid: boolean; count: number }>;
    onProcessTextData: (data: { item: string, totalSpent: number, category: string }[]) => void;
    onGoToResult: () => void;
    onSetRusherPersona: () => void;
    isLoading: boolean;
}

const PRIMARY_BLUE = '#3182F6';

const UploadPage: React.FC<UploadPageProps> = ({ dataCount, onFileUpload, onImageUpload, onProcessTextData, onGoToResult, onSetRusherPersona, isLoading }) => {
    const [imageFiles, setImageFiles] = useState<File[]>([]);
    const [invalidImageWarning, setInvalidImageWarning] = useState(false);
    const [analyzeButtonClickCount, setAnalyzeButtonClickCount] = useState(0);

    const handleImagesChange = (files: File[]) => {
        setImageFiles(files);
        // If the user changes/removes the image that caused the warning, reset the warning state.
        if (invalidImageWarning) {
            setInvalidImageWarning(false);
            setAnalyzeButtonClickCount(0);
        }
    };
    
    const handleAnalyzeClick = async () => {
        if (imageFiles.length > 0 && !invalidImageWarning) {
            const result = await onImageUpload(imageFiles);
            if (!result.valid) {
                setInvalidImageWarning(true);
                alert("잘못된 이미지가 포함되어 있습니다. 제거하거나, 다시 한 번 버튼을 누르면 특별 페르소나로 분석이 진행됩니다.");
                return;
            }
        }
        
        if (invalidImageWarning) {
            if (analyzeButtonClickCount === 0) {
                setAnalyzeButtonClickCount(1);
                // The user needs to click again to confirm.
                return;
            } else {
                onSetRusherPersona();
                return;
            }
        }

        onGoToResult();
    };

    const canProceed = (dataCount > 0 || imageFiles.length > 0) && !isLoading;

    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col">
        <header className="bg-white border-b border-gray-200">
            <div className="max-w-2xl mx-auto px-5 py-4 flex items-center justify-center">
                <div className="flex items-center gap-2">
                    <div style={{ backgroundColor: PRIMARY_BLUE }} className="w-8 h-8 rounded-lg flex items-center justify-center">
                        <TrendingUp size={20} className="text-white" />
                    </div>
                    <h1 className="text-2xl font-bold" style={{ color: PRIMARY_BLUE }}>Spendy</h1>
                </div>
            </div>
        </header>

        <main className="flex-grow">
            <div className="max-w-2xl mx-auto px-5 py-8">
                <div className="text-center mb-10">
                    <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">
                        소비 데이터를<br />업로드해주세요
                    </h2>
                    <p className="text-gray-600 text-base">당신의 소비 패턴을 AI가 분석해드립니다</p>
                </div>

                {invalidImageWarning && (
                    <div className="bg-red-50 border-2 border-red-300 rounded-2xl p-4 mb-4 flex items-start gap-3">
                        <AlertCircle className="text-red-600 flex-shrink-0 mt-0.5" size={24} />
                        <div>
                            <h3 className="font-bold text-red-900 mb-1">⚠️ 잘못된 이미지 감지</h3>
                            <p className="text-sm text-red-800">
                                토스, 은행 앱 거래 내역, 영수증 등 금융 관련 이미지를 업로드해주세요. 경고를 무시하고 진행하면 '생각없는 직진가' 페르소나가 부여됩니다.
                            </p>
                        </div>
                    </div>
                )}
                
                <div className="space-y-4">
                    <FileInput onFileSelect={onFileUpload} />
                    <ImageInput onImagesChange={handleImagesChange} />
                    <TextInput onTextSubmit={onProcessTextData} />
                </div>
            </div>
        </main>
        
        <footer className="sticky bottom-0 bg-white/80 backdrop-blur-sm p-4 border-t border-gray-200">
             <div className="max-w-2xl mx-auto">
                {(dataCount > 0 || imageFiles.length > 0) && (
                    <div className="bg-blue-100 rounded-xl p-3 mb-4 text-center border border-blue-200">
                        <p className="font-semibold" style={{ color: '#1E40AF' }}>
                            총 <span className="text-2xl font-bold" style={{color: PRIMARY_BLUE}}>{dataCount + imageFiles.length}</span>개의 데이터가 준비되었습니다.
                        </p>
                    </div>
                )}
                <button
                    onClick={handleAnalyzeClick}
                    disabled={!canProceed}
                    style={{ backgroundColor: canProceed ? PRIMARY_BLUE : '' }}
                    className="w-full text-white font-bold py-4 rounded-2xl hover:opacity-90 transition-all shadow-lg flex items-center justify-center gap-2 text-lg disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    {isLoading ? <LoaderCircle className="animate-spin" size={24} /> : <>분석 결과 보기 <ArrowRight size={24} /></>}
                </button>
             </div>
        </footer>
      </div>
    );
};

export default UploadPage;
