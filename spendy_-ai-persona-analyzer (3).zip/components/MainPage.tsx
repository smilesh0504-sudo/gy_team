
import React from 'react';
import { TrendingUp, LogIn, UserPlus } from 'lucide-react';

interface MainPageProps {
    onNavigateToLogin: () => void;
    onNavigateToSignUp: () => void;
}

const PRIMARY_BLUE = '#3182F6';

const MainPage: React.FC<MainPageProps> = ({ onNavigateToLogin, onNavigateToSignUp }) => {
    return (
        <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex flex-col items-center justify-center text-center p-5">
            <div className="flex flex-col items-center gap-4 mb-12">
                <div style={{ backgroundColor: PRIMARY_BLUE }} className="w-24 h-24 rounded-3xl flex items-center justify-center shadow-lg">
                    <TrendingUp size={60} className="text-white" />
                </div>
                <h1 className="text-5xl font-bold" style={{ color: PRIMARY_BLUE }}>Spendy</h1>
                <p className="text-gray-600 text-lg">AI가 분석해주는 나의 소비 페르소나</p>
            </div>

            <div className="w-full max-w-xs space-y-4">
                <button
                    onClick={onNavigateToLogin}
                    style={{ backgroundColor: PRIMARY_BLUE }}
                    className="w-full text-white font-bold py-4 rounded-2xl hover:opacity-90 transition-all shadow-lg flex items-center justify-center gap-2 text-lg"
                >
                    <LogIn size={24} />
                    로그인
                </button>
                <button
                    onClick={onNavigateToSignUp}
                    className="w-full text-gray-700 font-bold py-4 rounded-2xl hover:bg-gray-200 transition-all bg-white border-2 border-gray-200 flex items-center justify-center gap-2 text-lg"
                >
                    <UserPlus size={24} />
                    회원가입
                </button>
            </div>
        </div>
    );
};

export default MainPage;
