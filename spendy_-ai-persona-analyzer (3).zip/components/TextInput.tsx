import React from 'react';
import { FileText } from 'lucide-react';

const PRIMARY_BLUE = '#3182F6';

interface TextInputProps {
    onTextSubmit: (data: { item: string, totalSpent: number, category: string }[]) => void;
}

const TextInput: React.FC<TextInputProps> = ({ onTextSubmit }) => {
    const handleTextBlur = (e: React.FocusEvent<HTMLTextAreaElement>) => {
        const text = e.target.value;
        if (!text.trim()) return;

        const lines = text.split('\n').filter(line => line.trim() !== '');
        const parsed = lines.map(line => {
            const parts = line.split(/\s+/);
            const amountStr = parts.pop() || '0';
            const amount = Math.abs(parseFloat(amountStr.replace(/,/g, '')));
            const item = parts.join(' ');
            return { item, totalSpent: isNaN(amount) ? 0 : amount, category: '알 수 없음' };
        }).filter(d => d.item && d.totalSpent > 0);

        if (parsed.length > 0) {
            onTextSubmit(parsed);
            e.target.value = '';
        }
    };

    return (
        <div className="bg-white rounded-2xl p-6 border-2 border-gray-200">
            <div className="text-center mb-3">
                <FileText className="mx-auto mb-2" style={{ color: PRIMARY_BLUE }} size={40} />
                <span className="text-base font-bold text-gray-900 block mb-1">텍스트로 입력</span>
                <span className="text-sm text-gray-500">한 줄에 하나씩 붙여넣으세요</span>
            </div>
            <textarea
                placeholder="예시:&#10;스타벅스 -4500&#10;점심 12000&#10;카카오택시 -8000"
                onBlur={handleTextBlur}
                className="w-full h-32 bg-gray-100 rounded-xl p-4 border-0 focus:outline-none focus:ring-2 resize-none text-sm text-gray-700"
                style={{'--tw-ring-color': PRIMARY_BLUE} as React.CSSProperties}
            />
        </div>
    );
};

export default TextInput;
