import type { Persona } from '../types';

export const PERSONAS: { [key: string]: Persona } = {
    '식비': { name: '미식가', iconPrompt: 'A fork and knife crossed', color: '#FFB800', description: '맛있는 음식을 즐기는 데\n지출이 많으시네요', comment: '다양한 맛을 탐험하는 당신은 진정한 미식가입니다.' },
    '쇼핑': { name: '쇼핑 러버', iconPrompt: 'A shopping bag with a small heart on it', color: '#FF6482', description: '쇼핑을 통해 삶의 만족도를\n높이시는군요', comment: '새로운 것을 찾는 즐거움을 아는 당신, 멋져요!' },
    '주거': { name: '홈 메이커', iconPrompt: 'A simple, modern house icon', color: '#00C471', description: '주거 관련 지출이 소비에서\n큰 비중을 차지하네요', comment: '편안한 공간을 만드는 데 투자하는 현명한 선택입니다.' },
    '교통비': { name: '액티브 무버', iconPrompt: 'A modern bus or subway icon', color: '#3182F6', description: '이동이 잦거나 교통 관련\n지출이 많은 편이시네요', comment: '세상을 누비는 활동적인 라이프스타일!' },
    '문화/여가': { name: '라이프 엔조이어', iconPrompt: 'A movie ticket and a star', color: '#8B5CF6', description: '다양한 문화 및 여가 활동에\n적극적으로 참여하시는군요', comment: '삶을 풍요롭게 만드는 멋진 취미생활을 하고 계세요.' },
    '생활비': { name: '라이프 매니저', iconPrompt: 'A water droplet inside a leaf shape', color: '#14B8A6', description: '필수적인 생활비 지출이\n상대적으로 높게 나타납니다', comment: '건강과 일상을 챙기는 책임감 있는 당신, 응원합니다.' },
    '알 수 없음': { name: '미스터리 소비자', iconPrompt: 'A magnifying glass over a question mark', color: '#A0AEC0', description: '분류하기 어려운 소비가\n많이 발견되었습니다', comment: '독특한 소비 패턴을 가진 흥미로운 당신이네요.' },
    '생각없는 직진가': { name: '생각없는 직진가', iconPrompt: 'A cartoon rocket ship about to crash into a planet', color: '#F44336', description: '잘못된 데이터를 포함하여\n분석을 요청하셨습니다', comment: '잘못된 데이터는 인식할 수 없어요. 정확한 분석을 위해 올바른 형식의 데이터를 업로드해주세요!' }
};
